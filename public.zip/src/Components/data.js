
const Data = [ 
	{ 
		id: 1, 
		name: "react", 
		img: 
"https://tse3.mm.bing.net/th?id=OIP.osJ2QEq7X_AxhZ2iJcGvmgHaFj&pid=Api&P=0&h=180", 
		matched: false, 
	}, 
	{ 
		id: 2, 
		name: "java", 
		img: 
"https://tse2.mm.bing.net/th?id=OIP.-5tnHAX5B8R0J5WufbBkfwHaFW&pid=Api&P=0&h=180", 
		matched: false, 
	}, 
	{ 
		id: 3, 
		name: "css", 
		img: 
"https://tse2.mm.bing.net/th?id=OIP.aIKbQEUcHDQrY_obuEGaLQHaHN&pid=Api&P=0&h=180", 
		matched: false, 
	}, 
	{ 
		id: 4, 
		name: "node", 
		img: 
"https://tse4.mm.bing.net/th?id=OIP.GSjGJpjdm0zhEs8JGqHFjQHaF9&pid=Api&P=0&h=180", 
		matched: false, 
	}, 
	{ 
		id: 5, 
		name: "html", 
		img: 
"https://tse4.mm.bing.net/th?id=OIP.N56dEIRLjmbaGX0apFSPhQHaFS&pid=Api&P=0&h=180", 
		matched: false, 
	}, 
	{ 
		id: 6, 
		name: "js", 
		img: 
"https://tse2.mm.bing.net/th?id=OIP.Aw3SVWgHT9-8mCkIaY4zBwHaHq&pid=Api&P=0&h=180", 
		matched: false, 
	}, 
	{ 
		id: 7, 
		name: "react", 
		img: 
"https://tse3.mm.bing.net/th?id=OIP.osJ2QEq7X_AxhZ2iJcGvmgHaFj&pid=Api&P=0&h=180", 
		matched: false, 
	}, 
	{ 
		id: 8, 
		name: "java", 
		img: 
"https://tse2.mm.bing.net/th?id=OIP.-5tnHAX5B8R0J5WufbBkfwHaFW&pid=Api&P=0&h=180", 
		matched: false, 
	}, 
	{ 
		id: 9, 
		name: "css", 
		img: 
"https://tse2.mm.bing.net/th?id=OIP.aIKbQEUcHDQrY_obuEGaLQHaHN&pid=Api&P=0&h=180", 
		matched: false, 
	}, 
	{ 
		id: 10, 
		name: "node", 
		img: 
"https://tse4.mm.bing.net/th?id=OIP.GSjGJpjdm0zhEs8JGqHFjQHaF9&pid=Api&P=0&h=180", 
		matched: false, 
	}, 
	{ 
		id: 11, 
		name: "html", 
		img: 
"https://tse4.mm.bing.net/th?id=OIP.N56dEIRLjmbaGX0apFSPhQHaFS&pid=Api&P=0&h=180", 
		matched: false, 
	}, 
	{ 
		id: 12, 
		name: "js", 
		img: 
"https://tse2.mm.bing.net/th?id=OIP.Aw3SVWgHT9-8mCkIaY4zBwHaHq&pid=Api&P=0&h=180", 
		matched: false, 
	}, 
]; 
export default Data;